
; ------------------------------------------------------------
; VZ200/VZ300 Plasma (128x64) � Fast per-nibble +1 colour rotate
; Colours: 00=Green -> 01=Yellow -> 10=Blue -> 11=Red -> 00
; No IX, no PUSH/POP BC. Table is page-aligned for LD L,A indexing.
; ------------------------------------------------------------

        org     $8000

buffer  equ     $9000          ; off-screen buffer (2KB)
vram    equ     $7000          ; video RAM start (2KB)
latch   equ     $6800          ; mode / vsync latch
BYTES   equ     2048

; ------------------------------------------------------------
; Enter graphics mode
; ------------------------------------------------------------
start:
        di
        ld      a,8
        ld      (latch),a      ; MODE(1)

; ------------------------------------------------------------
; Build 256-byte lookup table for 2-bit-per-pixel +1 (mod 4)
; For each 2-bit pair (x1:x0):
;   y0 = ~x0
;   y1 = x1 XOR x0
; Byte-wide formula:
;   new = (~x & 0x55) | ((x & 0xAA) ^ ((x & 0x55) << 1))
; ------------------------------------------------------------
        ld      hl, rot2        ; HL points to start of table
        ld      c,0             ; C = 0..255 (256 entries)
mk_tbl:
        ld      a,c             ; x
        ld      e,a             ; keep original x in E

        ; t = (x & 0x55) << 1
        ld      a,e
        and     %01010101
        add     a,a
        ld      d,a             ; D = t

        ; msb_part = (x & 0xAA) ^ t
        ld      a,e
        and     %10101010
        xor     d
        ld      d,a             ; D = msb_part

        ; lsb_part = (~x & 0x55)
        ld      a,e
        cpl
        and     %01010101

        ; combine and store
        or      d
        ld      (hl),a
        inc     hl
        inc     c
        jr      nz, mk_tbl      ; 256 entries when C wraps

; ------------------------------------------------------------
; Copy initial plasma image into buffer
; ------------------------------------------------------------
        ld      hl, image1
        ld      de, buffer
        ld      bc, BYTES
        ldir

; ------------------------------------------------------------
; Main loop: rotate colours in buffer, vsync, copy to VRAM
; ------------------------------------------------------------
plasy:
        ; --- Fast per-byte transform using page-aligned table ---
        ld      h, HIGH(rot2)   ; keep H fixed to table page
        ld      de, buffer
        ld      bc, BYTES

rotlp:
        ld      a,(de)          ; read 4 pixels
        ld      l,a             ; HL = rot2 + A  (page-aligned!)
        ld      a,(hl)          ; rotated result
        ld      (de),a          ; write back to buffer
        inc     de

        ; BC 16-bit down-counter (no PUSH/POP)
        dec     bc
        ld      a,b
        or      c
        jr      nz, rotlp

        ; --- Wait for vertical retrace ---
        ld      hl, latch
sync2:  bit     7,(hl)
        jr      nz, sync2

;        ld      hl, latch
;sync3:  bit     7,(hl)
;        jr      nz, sync3

        ; --- Blit buffer to video RAM ---
        ld      hl, buffer
        ld      de, vram
        ld      bc, BYTES
        ldir

        jp      plasy


; ------------------------------------------------------------
; Page-aligned lookup table storage (filled at runtime)
; IMPORTANT: rot2 must sit at low byte = 0 for LD L,A indexing.
; We place it explicitly at $8200 (page boundary).
; ------------------------------------------------------------
        org     $8200
rot2:
        defs    256             ; 256-byte table (uninitialized; built at runtime)

; ------------------------------------------------------------
; Initial image (2KB) placed after the table; safe gap to buffer
; ------------------------------------------------------------
        org     $8300
image1:
 file:
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
defb $0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095
defb $07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9
defb $0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055
defb $07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5
defb $0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015
defb $07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1
defb $0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005
defb $07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000
defb $0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001
defb $07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000
defb $0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000
defb $07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
defb $0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095
defb $07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9
defb $0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055
defb $07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5
defb $0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015
defb $07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1
defb $0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005
defb $07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000
defb $0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001
defb $07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000
defb $0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000
defb $07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
defb $0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095
defb $07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9
defb $0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055
defb $07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5
defb $0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015
defb $07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1
defb $0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005
defb $07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000
defb $0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001
defb $07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000
defb $0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000
defb $07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
defb $0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095
defb $07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9
defb $0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055
defb $07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5
defb $0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015
defb $07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1
defb $0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005
defb $07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000
defb $0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001
defb $07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000
defb $0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000
defb $07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
defb $0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095
defb $07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9
defb $0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055
defb $07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5
defb $0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015
defb $07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1
defb $0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005
defb $07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000
defb $0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001
defb $07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000
defb $0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000
defb $07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
defb $0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095
defb $07F,$0FA,$055,$0FF,$0E9,$057,$0FF,$0A5,$05F,$0FE,$095,$07F,$0FA,$055,$0FF,$0E9
defb $0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055
defb $07F,$0FD,$055,$0FF,$0F5,$057,$0FF,$0D5,$05F,$0FF,$055,$07F,$0FD,$055,$0FF,$0F5
defb $0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015
defb $07F,$0F0,$055,$0FF,$0C1,$057,$0FF,$005,$05F,$0FC,$015,$07F,$0F0,$055,$0FF,$0C1
defb $0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005
defb $07F,$0C0,$015,$0FF,$000,$057,$0FC,$001,$05F,$0F0,$005,$07F,$0C0,$015,$0FF,$000
defb $0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001
defb $07F,$000,$005,$0FC,$000,$017,$0F0,$000,$05F,$0C0,$001,$07F,$000,$005,$0FC,$000
defb $0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000
defb $07C,$000,$001,$0F0,$000,$007,$0C0,$000,$01F,$000,$000,$07C,$000,$001,$0F0,$000
defb $0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA
defb $0BA,$0AA,$0AA,$0EA,$0AA,$0AB,$0AA,$0AA,$0AE,$0AA,$0AA,$0BA,$0AA,$0AA,$0EA,$0AA
defb $0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA
defb $07E,$0AA,$0A9,$0FA,$0AA,$0A7,$0EA,$0AA,$09F,$0AA,$0AA,$07E,$0AA,$0A9,$0FA,$0AA
defb $0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9
defb $07F,$0AA,$0A5,$0FE,$0AA,$097,$0FA,$0AA,$05F,$0EA,$0A9,$07F,$0AA,$0A5,$0FE,$0AA
defb $0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5
defb $07F,$0EA,$095,$0FF,$0AA,$057,$0FE,$0A9,$05F,$0FA,$0A5,$07F,$0EA,$095,$0FF,$0AA
 ; ---------------------------------------------------------

