/*
3d.c
Demo using standard Wizard 3d and 4d math functions
Copyright� 2002, Mark Hamilton
Flickering (non paged graphics) port to Z88DK by Stefano Bodrato - Oct 2003


- A silly demo thing whipper up by Dave.
- Using VZ_LINE2 ASM
- Uses background from Magnum Quest.
- Needs to run at Super Speed in VZEM for decent animation.


*/

// zcc +zx -vn showlib3d.c -o showlib3d -lndos -llib3d -create-app

//#include <oz.h>
#include <lib3d.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <vz.h>

#define MX	60
#define MX2	60
#define MY	64/2



Vector_t table[8]
=     { { -40 ,   10,   0  },
	{ -40 ,  -10,   0  },
	{ -60 ,  -10,   0  },
	{ -60 ,   10,   0  },
	{ -40 ,   10,  -10 },
	{ -40 ,  -10,  -10 },
	{ -60 ,  -10,  -10 },
	{ -60 ,   10,  -10 }};


Vector_t tv[11]
=     { {  35 ,  10,  5 },
	{  65 ,  10,  5 },
	{  65 , -10,  5 },
	{  35 , -10,  5 },
	{  35 ,  10,  0 },
	{  65 ,  10,  0 },
	{  65 , -10,  0 },
	{  35 , -10,  0 },
	{  50 ,  10,  2 },
	{  56 ,  18,  2 },
	{  44 ,  18,  2 }};


Vector_t chair[10]
=     { { -10 ,  10,   0 },
	{  10 ,  10,   0 },
	{  10 , -10,   0 },
	{ -10 , -10,   0 },
	{ -10 ,  10,  -15 },
	{  10 ,  10,  -15 },
	{  10 , -10,  -15 },
	{ -10 , -10,  -15 },
	{ -10 , -10,   20 },
	{  10 , -10,   20 }};


Vector_t pic[7]
=     { {  20 ,  -10, -20 },
	{  30 ,  -10, -20 },
	{  30 ,  00,  -20 },
	{  20 ,  00,  -20 },
	{  25 ,  -15, -20 },
	{  22 ,  -10, -20 },
	{  28 ,  -10, -20 }};



int vz_line2(int x1, int y1, int x2, int y2, int c)
{
  #asm
	ld	hl, 2
	add	hl, sp
	ld	c, (hl)			// get C. C=colour
	inc	hl
	inc	hl
	ld	d, (hl)			// get Y2. d=Y2
	inc	hl
	inc	hl
	ld	e, (hl)			// get X2. e=X2
	inc	hl
	inc	hl
	ld	a, (hl)			// get Y1. temp make A=Y1
	inc	hl
	inc	hl
	ld	l, (hl)			// get X1. L=x1
	ld	h, a			// set h=Y1 from temp A.

   
   ; c = colour
   ; l = x1
   ; h = y1
   ; e = x2
   ; d = y2
   
asmentry:

   ld a,e
   cp l
   jr nc, line1
   ex de,hl                  ; swap so that x1 < x2

line1:

   ld a,e
   sub l                     ; dx
   ld e,a                    ; save dx

   ld a,d
   sub h
   jp c, lup                 ; negative (up)

ldn:

   ld d,a                    ; save dy
   cp e                      ; dy < dx ?
   jr c, ldnx

ldny:

   ld b,a                    ; count = dy
   srl a                     ; /2 -> overflow

ldny1:

   push af		; push return
   push bc		; push colour
;   push de		; push Y2/X2
   push hl		; push Y1/X1
;=============================

;; ----- void __CALLEE__ vz_plot_callee(int x, int y, int c)
;;   pop af  	return add
;;   pop bc	colour
;;   pop de	Y
;;   pop hl	X
;;   push af	push return add
;;   ld h,e
;;
;;   ----  h=y1 / l=x1
;;         d=y2 / e=x2


   ; l = x
   ; h = y
   ; c = colour



;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
      ld a,$fc
pset1:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset1
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   
   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m

   inc h                     ; y++
   sub e                     ; overflow -= dx
   jr nc, ldny1
 
   inc l                     ; x++
   add a,d                   ; overflow += dy
   jp ldny1

ldnx:

   ld a,e                    ; get dx
   ld b,a                    ; count = dx
   srl a                     ; /2 -> overflow
   
ldnx1:

   push af
   push bc
;   push de
   push hl
;=============================
;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;  and 3
;  ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
      ld a,$fc
pset2:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset2
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   
   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m
   
   inc l                     ; x++
   sub d                     ; overflow -= dy
   jr nc, ldnx1

   inc h                     ; y++
   add a,e                   ; overflow += dx
   jp ldnx1

lup:

   neg                       ; make dy positive
   ld d,a                    ; save dy
   cp e                      ; dy < dx ?
   jr c, lupx

lupy:

   ld b,a                    ; count = dy
   srl a                     ; /2 -> overflow

lupy1:

   push af
   push bc
;   push de
   push hl

;=============================
;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
   ld a,$fc
pset3:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset3
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   


   pop hl
;   pop de
   pop bc
   pop af

   dec b                     ; done?
   ret m

   dec h                     ; y--
   sub e                     ; overflow -= dx
   jr nc, lupy1

   inc l                     ; x++
   add a,d                   ; overflow += dy
   jp lupy1

lupx:

   ld a,e                    ; get dx
   ld b,a                    ; count = dx
   srl a                     ; /2 -> overflow

lupx1:

   push af
   push bc
;   push de
   push hl



;=============================

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l
   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
   ld a,$fc
pset4:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset4
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   




   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m

   inc l                     ; x++
   sub d                     ; overflow -= dy
   jr nc, lupx1

   dec h                     ; y--
   add a,e                   ; overflow += dx
   jp lupx1

   #endasm
}




// ==============================================================
// Data of "PICT4" graphic background "PICT4" from Magnum Quest.
// ==============================================================
void background (void){		
 	#asm

	ld	hl, backg	//Loads background to $C000.
	ld	de, $c000
	ld	bc, 2048
	ldir
		ret
backg:
defb $000,$000,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0C0,$000,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FC,$000,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0C0,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FC,$000,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0C0,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FC,$000,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0C0,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FC,$000,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00F,$0FF,$0FF,$0FF,$0FC,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00F,$0FF,$0FF,$0FF,$0FC,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00F,$0FF,$0FF,$0FF,$0FC,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00D,$055,$05F,$055,$05C,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$00F,$0FF,$0FF,$0FF,$0FC,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$000,$003,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$00D,$055,$055,$055,$055,$000,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$007,$055,$055,$055,$055,$040,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$0D5,$055,$055,$055,$050,$000,$000,$000
defb $0F5,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$075,$055,$055,$055,$054,$000,$000,$000
defb $0F7,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$05D,$055,$055,$055,$055,$000,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$057,$055,$055,$055,$055,$040,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$0D5,$055,$055,$055,$050,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$075,$055,$055,$055,$054,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$05F,$055,$055,$055,$055,$000,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$0D5,$055,$055,$055,$050,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$075,$055,$055,$055,$054,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$05D,$055,$055,$055,$055,$000
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$057,$055,$055,$055,$055,$040
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$055,$0D5,$055,$055,$055,$050
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$055,$075,$055,$055,$055,$054
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$030,$000,$000,$000,$000,$000,$000,$000,$000,$000
defb $000,$000,$000,$000,$000,$000,$000,$005,$055,$055,$055,$05D,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$055,$055,$055,$057,$0FF,$0FF,$0FF,$0FF
defb $0FF,$0FF,$0FF,$0FF,$0C0,$000,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$055,$055,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0C0,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$095,$055,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0C0,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A5,$055,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0C0,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$055,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0C0,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$055,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0C2,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$095,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$0CA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A5,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FF,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0FD,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$055,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0F6,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$095,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$0DA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A9,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FF,$06A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$057,$055,$055,$055,$055
defb $0FF,$0FF,$0FD,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$097,$055,$055,$055,$055
defb $0FF,$0FF,$0F6,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A7,$055,$055,$055,$055
defb $0FF,$0FF,$0DA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$055,$055,$055,$055
 ; ---------------------------------------------------------


	#endasm
}



void main(void)
{
	static Vector_t rot;
	static Vector_t t;
	static Point_t  p[10];

	static Vector_t rot2;
	static Vector_t t2;
	static Point_t  p2[10];

	static Vector_t rot3;
	static Vector_t t3;
	static Point_t  p3[11];

	static Vector_t rot4;
	static Vector_t t4;
	static Point_t  p4[7];

	static unsigned c = 0;
	static int i;
	static int zf = 50;
	static int zf2 = 150;

	vz_mode(1);

	background();

	#asm
		di
	#endasm

	while(1){

		c = 0;

		for(i=0;i<8;i++) {
			ozcopyvector(&t,&table[i]);	// Table
			ozrotatepointx(&t, rot.x);
			ozrotatepointy(&t, rot.y);
			ozrotatepointz(&t, rot.z);
			t.z += zf; 			// Zoom factor
			ozplotpoint(&t, &p[i]);
		}

		for(i=0;i<10;i++) {
			ozcopyvector(&t2,&chair[i]);	// Chair
			ozrotatepointx(&t2, rot2.x);
			ozrotatepointy(&t2, rot2.y);
			ozrotatepointz(&t2, rot2.z);
			t2.z += zf2; 			// Zoom factor 
			ozplotpoint(&t2, &p2[i]);
		}

		for(i=0;i<11;i++) {
			ozcopyvector(&t3,&tv[i]);	// TV
			ozrotatepointx(&t3, rot3.x);
			ozrotatepointy(&t3, rot3.y);
			ozrotatepointz(&t3, rot3.z);
			t3.z += zf2; 			// zoom factor
			ozplotpoint(&t3, &p3[i]);
		}

		for(i=0;i<7;i++) {
			ozcopyvector(&t4,&pic[i]);	// Table
			ozrotatepointx(&t4, rot4.x);
			ozrotatepointy(&t4, rot4.y);
			ozrotatepointz(&t4, rot4.z);
			t4.z += zf; 			// Zoom factor
			ozplotpoint(&t4, &p4[i]);
		}


		rot.y = (rot.y+2)%360;			// add rotation
		rot.x = (rot.x+4)%360;
		rot.z = (rot.z+4)%360;
		rot2.y = (rot2.y+3)%360;
		rot2.x = (rot2.x+3)%360;
		rot2.z = (rot2.z+3)%360;
		rot3.y = (rot3.y+5)%360;
		rot3.x = (rot3.x+4)%360;
		rot3.z = (rot3.z+4)%360;
		rot4.y = (rot3.y+2)%360;
		rot4.x = (rot3.x+2)%360;
		rot4.z = (rot3.z+1)%360;

		
		#asm			

		ld	hl, $b000	// blit from buffer to screen.
		ld	de, $7000
		ld	bc, 2048
		ldir

		ld	hl, $C000	// blit from background grafx at $C000 to buffer at $B000.
		ld	de, $b000
		ld	bc, 2048
		ldir


//		ld	hl, $b000	// CLS buffer
//		ld	de, $b001
//		ld	(hl), 0
//		ld	bc, 2048
//		ldir

		#endasm


// chair
		vz_line2(p2[0].x + MX2, p2[0].y + MY, p2[1].x + MX2, p2[1].y + MY,2); //seat
		vz_line2(p2[1].x + MX2, p2[1].y + MY, p2[2].x + MX2, p2[2].y + MY,2);
		vz_line2(p2[2].x + MX2, p2[2].y + MY, p2[3].x + MX2, p2[3].y + MY,2);
		vz_line2(p2[3].x + MX2, p2[3].y + MY, p2[0].x + MX2, p2[0].y + MY,2);
		vz_line2(p2[0].x + MX2, p2[0].y + MY, p2[4].x + MX2, p2[4].y + MY,2); //legs
		vz_line2(p2[1].x + MX2, p2[1].y + MY, p2[5].x + MX2, p2[5].y + MY,2);
		vz_line2(p2[2].x + MX2, p2[2].y + MY, p2[6].x + MX2, p2[6].y + MY,2);
		vz_line2(p2[3].x + MX2, p2[3].y + MY, p2[7].x + MX2, p2[7].y + MY,2);
		vz_line2(p2[2].x + MX2, p2[2].y + MY, p2[9].x + MX2, p2[9].y + MY,2); //back of chair
		vz_line2(p2[3].x + MX2, p2[3].y + MY, p2[8].x + MX2, p2[8].y + MY,2);
		vz_line2(p2[8].x + MX2, p2[8].y + MY, p2[9].x + MX2, p2[9].y + MY,2);


// TABLE
		vz_line2(p[0].x + MX2, p[0].y + MY, p[1].x + MX2, p[1].y + MY,1);  //top
		vz_line2(p[1].x + MX2, p[1].y + MY, p[2].x + MX2, p[2].y + MY,1);
		vz_line2(p[2].x + MX2, p[2].y + MY, p[3].x + MX2, p[3].y + MY,1);
		vz_line2(p[3].x + MX2, p[3].y + MY, p[0].x + MX2, p[0].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[4].x + MX2, p[4].y + MY,1);  // legs
		vz_line2(p[1].x + MX2, p[1].y + MY, p[5].x + MX2, p[5].y + MY,1);
		vz_line2(p[2].x + MX2, p[2].y + MY, p[6].x + MX2, p[6].y + MY,1);
		vz_line2(p[3].x + MX2, p[3].y + MY, p[7].x + MX2, p[7].y + MY,1);


// TV
		vz_line2(p3[0].x + MX2, p3[0].y + MY, p3[1].x + MX2, p3[1].y + MY,3); //box
		vz_line2(p3[1].x + MX2, p3[1].y + MY, p3[2].x + MX2, p3[2].y + MY,3);
		vz_line2(p3[2].x + MX2, p3[2].y + MY, p3[3].x + MX2, p3[3].y + MY,3);
		vz_line2(p3[3].x + MX2, p3[3].y + MY, p3[0].x + MX2, p3[0].y + MY,3);
		vz_line2(p3[4].x + MX2, p3[4].y + MY, p3[5].x + MX2, p3[5].y + MY,3);
		vz_line2(p3[5].x + MX2, p3[5].y + MY, p3[6].x + MX2, p3[6].y + MY,3);
		vz_line2(p3[6].x + MX2, p3[6].y + MY, p3[7].x + MX2, p3[7].y + MY,3);
		vz_line2(p3[7].x + MX2, p3[7].y + MY, p3[4].x + MX2, p3[4].y + MY,3);
		vz_line2(p3[0].x + MX2, p3[0].y + MY, p3[4].x + MX2, p3[4].y + MY,3);
		vz_line2(p3[1].x + MX2, p3[1].y + MY, p3[5].x + MX2, p3[5].y + MY,3);
		vz_line2(p3[2].x + MX2, p3[2].y + MY, p3[6].x + MX2, p3[6].y + MY,3);
		vz_line2(p3[3].x + MX2, p3[3].y + MY, p3[7].x + MX2, p3[7].y + MY,3);
		vz_line2(p3[8].x + MX2, p3[8].y + MY, p3[9].x + MX2, p3[9].y + MY,3); // TV Aerial
		vz_line2(p3[8].x + MX2, p3[8].y + MY, p3[10].x + MX2, p3[10].y + MY,3);

// PICCY
		vz_line2(p4[0].x + MX2, p4[0].y + MY, p4[1].x + MX2, p4[1].y + MY,2); //box
		vz_line2(p4[1].x + MX2, p4[1].y + MY, p4[2].x + MX2, p4[2].y + MY,2);
		vz_line2(p4[2].x + MX2, p4[2].y + MY, p4[3].x + MX2, p4[3].y + MY,2);
		vz_line2(p4[3].x + MX2, p4[3].y + MY, p4[0].x + MX2, p4[0].y + MY,2);
		vz_line2(p4[4].x + MX2, p4[4].y + MY, p4[5].x + MX2, p4[5].y + MY,1);
		vz_line2(p4[4].x + MX2, p4[4].y + MY, p4[6].x + MX2, p4[6].y + MY,1);

	}
}



