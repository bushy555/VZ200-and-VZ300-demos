
/*
3d.c
Demo using standard Wizard 3d and 4d math functions
Copyright� 2002, Mark Hamilton
Flickering (non paged graphics) port to Z88DK by Stefano Bodrato - Oct 2003


- A silly demo thing whipper up by Dave.
- Using VZ_LINE2 ASM
- Uses background from Magnum Quest.
- Needs to run at Super Speed in VZEM for decent animation.


*/

// zcc +zx -vn showlib3d.c -o showlib3d -lndos -llib3d -create-app

//#include <oz.h>
#include <lib3d.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <vz.h>

#define MX	60
#define MX2	60
#define MY	64/2



Vector_t floor[24]
=     { {  -20, -20 ,   0 },	//
	{  -20, -20 ,   0 },			//0
	{  -10, -20 ,   0 },			//1
	{  0,   -20,   0 },			//2
	{  10,  -20,   0 },			//3
	{  20,  -20,   0 },			//4
	{  20,  -20,   0 },	// 6

        {  -20, 20 ,   0 },	// 7
	{  -20, 20 ,   0 },			//5
	{  -10, 20 ,   0 },			//6
	{  0,   20,   0 },			//7
	{  10,  20,   0 },			//8
	{  20,  20,   0 },			//9
	{  20,  20,   0 },	// 13


	{  -20,  -20,  0 },			//10
	{  -20,  -10,  0 },			//11
	{  -20,  -0 ,  0 },			//12
	{  -20,  10 ,  0 },			//13
	{  -20,  20 ,  0 },			//14

        {  20,   -20,  0 },			//15
	{  20,   -10,  0 },			//16
	{  20,   -0 ,  0 },			//17
	{  20,   10 ,  0 },			//18
	{  20,   20 ,  0 }};			//19







int vz_line2(int x1, int y1, int x2, int y2, int c)
{
  #asm
	ld	hl, 2
	add	hl, sp
	ld	c, (hl)			// get C. C=colour
	inc	hl
	inc	hl
	ld	d, (hl)			// get Y2. d=Y2
	inc	hl
	inc	hl
	ld	e, (hl)			// get X2. e=X2
	inc	hl
	inc	hl
	ld	a, (hl)			// get Y1. temp make A=Y1
	inc	hl
	inc	hl
	ld	l, (hl)			// get X1. L=x1
	ld	h, a			// set h=Y1 from temp A.

   
   ; c = colour
   ; l = x1
   ; h = y1
   ; e = x2
   ; d = y2
   
asmentry:
   	ld a,e
   	cp l
   	jr nc, line1
   	ex de,hl                  ; swap so that x1 < x2
line1: 	ld a,e
   	sub l                     ; dx
   	ld e,a                    ; save dx
   	ld a,d
   	sub h
   	jp c, lup                 ; negative (up)
ldn:	ld d,a                    ; save dy
   	cp e                      ; dy < dx ?
   	jr c, ldnx
ldny:	ld b,a                    ; count = dy
   	srl a                     ; /2 -> overflow
ldny1:


	ex	af, af'
   	push bc		; push colour
   	push hl		; push Y1/X1
   	ld 	a,l
   	sla 	l                     ; calculate screen offset
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	and 	$03                   ; pixel offset   
   	inc 	a
   	ld 	b,a
      	ld 	a,$fc
pset1:	rrca
   	rrca
   	rrc 	c
   	rrc 	c
   	djnz 	pset1
	add 	hl, $c000
   	and 	(hl)
   	or 	c
   	ld 	(hl),a
   	pop hl
   	pop bc
	ex	af, af'
   
   	dec b                     ; done?
   	ret m
   	inc h                     ; y++
   	sub e                     ; overflow -= dx
   	jr nc, ldny1
   	inc l                     ; x++
   	add a,d                   ; overflow += dy
   	jp ldny1
ldnx:	ld a,e                    ; get dx
   	ld b,a                    ; count = dx
   	srl a                     ; /2 -> overflow
ldnx1:


	ex	af, af'
   	push bc		; push colour
   	push hl		; push Y1/X1
   	ld 	a,l
   	sla 	l                     ; calculate screen offset
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	and 	$03                   ; pixel offset   
   	inc 	a
   	ld 	b,a
      	ld 	a,$fc
pset2:	rrca
   	rrca
   	rrc 	c
   	rrc 	c
   	djnz 	pset2
	add 	hl, $c000
   	and 	(hl)
   	or 	c
   	ld 	(hl),a
   	pop hl
   	pop bc
	ex	af, af'
   
   	dec b                     ; done?
   	ret m
   	inc l                     ; x++
   	sub d                     ; overflow -= dy
   	jr nc, ldnx1
   	inc h                     ; y++
   	add a,e                   ; overflow += dx
   	jp ldnx1
lup:   	neg                       ; make dy positive
   	ld d,a                    ; save dy
   	cp e                      ; dy < dx ?
   	jr c, lupx
lupy:  	ld b,a                    ; count = dy
   	srl a                     ; /2 -> overflow
lupy1:

	ex	af, af'
   	push bc		; push colour
   	push hl		; push Y1/X1
   	ld 	a,l
   	sla 	l                     ; calculate screen offset
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	and 	$03                   ; pixel offset   
   	inc 	a
   	ld 	b,a
      	ld 	a,$fc
pset3:	rrca
   	rrca
   	rrc 	c
   	rrc 	c
   	djnz 	pset3
	add 	hl, $c000
   	and 	(hl)
   	or 	c
   	ld 	(hl),a
   	pop hl
   	pop bc
	ex	af, af'

   	dec b                     ; done?
   	ret m
   	dec h                     ; y--
   	sub e                     ; overflow -= dx
   	jr nc, lupy1
   	inc l                     ; x++
   	add a,d                   ; overflow += dy
   	jp lupy1
lupx:  	ld a,e                    ; get dx
   	ld b,a                    ; count = dx
   	srl a                     ; /2 -> overflow
lupx1:





	ex	af, af'
   	push bc		; push colour
   	push hl		; push Y1/X1
   	ld 	a,l
   	sla 	l                     ; calculate screen offset
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	srl 	h
   	rr 	l
   	and 	$03                   ; pixel offset   
   	inc 	a
   	ld 	b,a
      	ld 	a,$fc
pset4:	rrca
   	rrca
   	rrc 	c
   	rrc 	c
   	djnz 	pset4
	add 	hl, $c000
   	and 	(hl)
   	or 	c
   	ld 	(hl),a
   	pop hl
   	pop bc
	ex	af, af'



   	dec b                     ; done?
   	ret m
   	inc l                     ; x++
   	sub d                     ; overflow -= dy
   	jr nc, lupx1
   	dec h                     ; y--
   	add a,e                   ; overflow += dx
   	jp lupx1



;   ----  h=y1 / l=x1
;         d=y2 / e=x2

; 	l = x
; 	h = y
; 	c = colour

		#endasm
}



void dovector(void)
{
	static Vector_t rot;
	static Vector_t t;
	static Point_t  p[24];

	static unsigned c = 0;
	static int i,j=0;
	static int zf = 50;
	static int zf2 = 150;


		ozcopyvector(&t,&floor[1]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[1]);

		ozcopyvector(&t,&floor[2]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[2]);

		ozcopyvector(&t,&floor[3]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[3]);

		ozcopyvector(&t,&floor[4]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[4]);

		ozcopyvector(&t,&floor[5]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[5]);

		ozcopyvector(&t,&floor[8]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[8]);

		ozcopyvector(&t,&floor[9]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[9]);

		ozcopyvector(&t,&floor[10]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[10]);

		ozcopyvector(&t,&floor[11]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[11]);

		ozcopyvector(&t,&floor[12]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[12]);


		ozcopyvector(&t,&floor[14]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[14]);

		ozcopyvector(&t,&floor[15]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[15]);

		ozcopyvector(&t,&floor[16]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[16]);

		ozcopyvector(&t,&floor[17]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[17]);

		ozcopyvector(&t,&floor[18]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[18]);

		ozcopyvector(&t,&floor[19]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[19]);

		ozcopyvector(&t,&floor[20]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[20]);

		ozcopyvector(&t,&floor[21]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[21]);

		ozcopyvector(&t,&floor[22]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[22]);

		ozcopyvector(&t,&floor[23]);	
		ozrotatepointx(&t, rot.x);
		ozrotatepointy(&t, rot.y);
		ozrotatepointz(&t, rot.z);
		t.z += zf; 			
		ozplotpoint(&t, &p[23]);

	

		rot.y += 2; 
                   if (rot.y >= 360) rot.y -= 360;
		rot.x += 4;  
                   if (rot.x >= 360) rot.x -= 360;
		rot.z += 4; 
                   if (rot.z >= 360) rot.z -= 360;



	vz_line2(p[14].x + MX2, p[14].y + MY, p[19].x + MX2, p[19].y + MY,1);  
	vz_line2(p[15].x + MX2, p[15].y + MY, p[20].x + MX2, p[20].y + MY,1);  
	vz_line2(p[16].x + MX2, p[16].y + MY, p[21].x + MX2, p[21].y + MY,1);  
	vz_line2(p[17].x + MX2, p[17].y + MY, p[22].x + MX2, p[22].y + MY,1);  
	vz_line2(p[18].x + MX2, p[18].y + MY, p[23].x + MX2, p[23].y + MY,1);  
	vz_line2(p[1].x + MX2, p[1].y + MY, p[8].x + MX2, p[8].y + MY,1);  
	vz_line2(p[2].x + MX2, p[2].y + MY, p[9].x + MX2, p[9].y + MY,1);  
	vz_line2(p[3].x + MX2, p[3].y + MY, p[10].x + MX2, p[10].y + MY,1);  
	vz_line2(p[4].x + MX2, p[4].y + MY, p[11].x + MX2, p[11].y + MY,1);  
	vz_line2(p[5].x + MX2, p[5].y + MY, p[12].x + MX2, p[12].y + MY,1);  
}


void main(void)
{

	vz_mode(1);


	while(1){




	
		#asm
	di
;	ld	hl, backg1
;	ld	de, $c000
;	ld	bc, 2048
;	ldir

 	ld 	hl, backg1
 	ld 	de, $c000
 	ld	b, 128          ; 128 iterations of 16 LDIs = 2048 bytes

copy_loop1:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop1




		#endasm
		dovector();
		#asm

 	ld 	hl, $c000
 	ld 	de, $7000
 	ld	b, 128         ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop1a:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop1a

		#endasm


		#asm
 	ld 	hl, backg2
 	ld 	de, $c000
 	ld	b, 128          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop2:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop2
		#endasm
		dovector();
		#asm
 	ld 	hl, $c000
 	ld 	de, $7000
 	ld	b, 128          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop2a:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop2a
		#endasm



		#asm
 	ld 	hl, backg3
 	ld 	de, $c000
 	ld	b, 64          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop3:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop3
		#endasm
		dovector();
		#asm
 	ld 	hl, $c000
 	ld 	de, $7000
 	ld	b, 64          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop3a:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop3a
		#endasm



		#asm
 	ld 	hl, backg4
 	ld 	de, $c000
 	ld	b, 64          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop4:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop4
		#endasm
		dovector();
		#asm
 	ld 	hl, $c000
 	ld 	de, $7000
 	ld	b, 64          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop4a:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop4a
		#endasm


		#asm
 	ld 	hl, backg5
 	ld 	de, $c000
 	ld	b, 64          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop5:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop5
		#endasm
		dovector();
		#asm
 	ld 	hl, $c000
 	ld 	de, $7000
 	ld	b, 64          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop5a:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop5a
		#endasm


		#asm
 	ld 	hl, backg6
 	ld 	de, $c000
 	ld	b, 128          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop6:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop6
		#endasm
		dovector();
		#asm
 	ld 	hl, $c000
 	ld 	de, $7000
 	ld	b, 128          ; 64 iterations of 16 LDIs = 2048 bytes

copy_loop6a:
ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	ldi \ ldi \ ldi \ldi
	djnz	copy_loop6a
		#endasm

	}





	#asm




backg6:
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF

backg5:
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF

backg4:
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA




backg3:
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA



backg2:
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA


backg1:
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF
defb $FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA,$FF,$AA



 ; ---------------------------------------------------------


	#endasm
}

}



