/*
3d.c
Demo using standard Wizard 3d and 4d math functions
Copyright� 2002, Mark Hamilton
Flickering (non paged graphics) port to Z88DK by Stefano Bodrato - Oct 2003


- A silly demo thing whipper up by Dave.
- Using VZ_LINE2 ASM
- Uses background from Magnum Quest.
- Needs to run at Super Speed in VZEM for decent animation.


*/

// zcc +zx -vn showlib3d.c -o showlib3d -lndos -llib3d -create-app

//#include <oz.h>
#include <lib3d.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <vz.h>

#define MX	60
#define MX2	60
#define MY	64/2 + 10



Vector_t ship[5]
=     { { -50 ,   -10,   -20  },
	{ -60 ,  -20,   -10  },
	{ -40 ,  -20,   -10  },
	{ -60 ,  0,   -10  },
	{ -40 ,  0,   -10 }};

Vector_t bee1[2]
=     { { -20 ,  -20,   -20  },
	{ -21 ,  -20,   -20  }};

Vector_t bee2[2]
=     { { 20 ,  20,   20  },
	{ 21 ,  20,   20  }};

Vector_t bee3[2]
=     { { -45 ,  5,   30  },
	{ -45 ,  6,   30  }};

Vector_t bee4[2]
=     { { -65 ,  -30,   30  },
	{ -65 ,  -31,   30  }};

Vector_t bee5[2]
=     { { 55 ,  30,   30  },
	{ 55 ,  31,   30  }};


int vz_line2(int x1, int y1, int x2, int y2, int c)
{
  #asm
	ld	hl, 2
	add	hl, sp
	ld	c, (hl)			// get C. C=colour
	inc	hl
	inc	hl
	ld	d, (hl)			// get Y2. d=Y2
	inc	hl
	inc	hl
	ld	e, (hl)			// get X2. e=X2
	inc	hl
	inc	hl
	ld	a, (hl)			// get Y1. temp make A=Y1
	inc	hl
	inc	hl
	ld	l, (hl)			// get X1. L=x1
	ld	h, a			// set h=Y1 from temp A.

   
   ; c = colour
   ; l = x1
   ; h = y1
   ; e = x2
   ; d = y2
   
asmentry:

   ld a,e
   cp l
   jr nc, line1
   ex de,hl                  ; swap so that x1 < x2

line1:

   ld a,e
   sub l                     ; dx
   ld e,a                    ; save dx

   ld a,d
   sub h
   jp c, lup                 ; negative (up)

ldn:

   ld d,a                    ; save dy
   cp e                      ; dy < dx ?
   jr c, ldnx

ldny:

   ld b,a                    ; count = dy
   srl a                     ; /2 -> overflow

ldny1:

   push af		; push return
   push bc		; push colour
;   push de		; push Y2/X2
   push hl		; push Y1/X1
;=============================

;; ----- void __CALLEE__ vz_plot_callee(int x, int y, int c)
;;   pop af  	return add
;;   pop bc	colour
;;   pop de	Y
;;   pop hl	X
;;   push af	push return add
;;   ld h,e
;;
;;   ----  h=y1 / l=x1
;;         d=y2 / e=x2


   ; l = x
   ; h = y
   ; c = colour



;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
      ld a,$fc
pset1:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset1
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   
   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m

   inc h                     ; y++
   sub e                     ; overflow -= dx
   jr nc, ldny1
 
   inc l                     ; x++
   add a,d                   ; overflow += dy
   jp ldny1

ldnx:

   ld a,e                    ; get dx
   ld b,a                    ; count = dx
   srl a                     ; /2 -> overflow
   
ldnx1:

   push af
   push bc
;   push de
   push hl
;=============================
;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;  and 3
;  ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
      ld a,$fc
pset2:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset2
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   
   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m
   
   inc l                     ; x++
   sub d                     ; overflow -= dy
   jr nc, ldnx1

   inc h                     ; y++
   add a,e                   ; overflow += dx
   jp ldnx1

lup:

   neg                       ; make dy positive
   ld d,a                    ; save dy
   cp e                      ; dy < dx ?
   jr c, lupx

lupy:

   ld b,a                    ; count = dy
   srl a                     ; /2 -> overflow

lupy1:

   push af
   push bc
;   push de
   push hl

;=============================
;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
   ld a,$fc
pset3:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset3
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   


   pop hl
;   pop de
   pop bc
   pop af

   dec b                     ; done?
   ret m

   dec h                     ; y--
   sub e                     ; overflow -= dx
   jr nc, lupy1

   inc l                     ; x++
   add a,d                   ; overflow += dy
   jp lupy1

lupx:

   ld a,e                    ; get dx
   ld b,a                    ; count = dx
   srl a                     ; /2 -> overflow

lupx1:

   push af
   push bc
;   push de
   push hl



;=============================

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l
   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
   ld a,$fc
pset4:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset4
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   




   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m

   inc l                     ; x++
   sub d                     ; overflow -= dy
   jr nc, lupx1

   dec h                     ; y--
   add a,e                   ; overflow += dx
   jp lupx1

   #endasm
}




// =======================
// Data of a sunny flower.
// =======================
void background (void){		
 	#asm

	ld	hl, backg	//Loads background to $C000.
	ld	de, $c000
	ld	bc, 2048
	ldir
	ret

backg:
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0BF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FE,$0AA,$0AF,$0FE,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0AA,$0BF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0AA,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0EB,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0EB,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0EF,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF
 defb $0FA,$0FF,$0FF,$0FF,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0AA,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0FF,$0D5,$055,$07F,$0FE,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0FD,$055,$055,$057,$0FB,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0F5,$055,$055,$055,$07F,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF
 defb $0FF,$0D5,$059,$055,$055,$05F,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF
 defb $0FF,$055,$066,$055,$055,$057,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BF
 defb $0FF,$055,$059,$055,$059,$055,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FD,$055,$055,$055,$066,$055,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0FD,$055,$055,$055,$059,$055,$07F,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FD,$055,$055,$055,$055,$055,$07F,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF,$0FF
 defb $0FD,$055,$055,$055,$055,$055,$07F,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BF,$0FF
 defb $0FD,$055,$065,$055,$055,$055,$07F,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF,$0FF
 defb $0FD,$055,$059,$055,$065,$055,$07F,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF,$0FF
 defb $0FD,$055,$056,$055,$095,$055,$07F,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF,$0FF
 defb $0FD,$055,$055,$0AA,$055,$055,$07F,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BF,$0FF
 defb $0FF,$055,$055,$055,$055,$055,$07F,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF,$0FF
 defb $0FF,$055,$055,$055,$055,$055,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FB,$0D5,$055,$055,$055,$055,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AF,$0F5,$055,$055,$055,$056,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0BF,$0FD,$055,$055,$055,$05F,$0AA,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0FF,$0FF,$0D5,$055,$055,$07F,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB
 defb $0FF,$0FF,$0FD,$055,$057,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FE,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FE,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FA,$0FF,$0FF,$0EF,$0FF,$0F2,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0FF,$0AA,$0FF,$0FF,$0AB,$0FF,$0C2,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0FF,$0FF,$0AA,$0A0,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0FF,$0FF,$0AA,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0BF,$0FE,$0A8,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AF,$0FA,$0A0,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A8
 defb $00A,$0AA,$0AA,$08A,$080,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $000,$02A,$0AA,$08A,$080,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $000,$002,$0AA,$08A,$000,$000,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $080,$000,$0AA,$08A,$000,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0A0,$000,$00A,$088,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0A0,$000,$002,$088,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0A8,$000,$002,$088,$000,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$000,$000,$080,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$080,$000,$082,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0A0,$000,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0A8,$000,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$080,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$082,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A0,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A0,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A0,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A8,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A8,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$082,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA

 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA


	#endasm
}



void main(void)
{
	static Vector_t rot;
	static Vector_t t;
	static Point_t  p[5];

	static Vector_t rot2;
	static Vector_t t2;
	static Point_t  p2[2];
	static Vector_t rot3;
	static Vector_t t3;
	static Point_t  p3[2];
	static Vector_t rot4;
	static Vector_t t4;
	static Point_t  p4[2];
	static Vector_t rot5;
	static Vector_t t5;
	static Point_t  p5[2];
	static Vector_t rot6;
	static Vector_t t6;
	static Point_t  p6[2];
	static int i;
	static int zf = 50;
	static int zf1 = 0;
	static int zf2 = 150;
	static int zf3 = 100;

	vz_mode(1);

	background();

	#asm
		di
	#endasm

	while(1){


		for(i=0;i<5;i++) {
			ozcopyvector(&t,&ship[i]);	// Table
			ozrotatepointx(&t, rot.x);
			ozrotatepointy(&t, rot.y);
			ozrotatepointz(&t, rot.z);
			t.z += zf3; 			// Zoom factor
			ozplotpoint(&t, &p[i]);
		}


		for(i=0;i<2;i++) {
			ozcopyvector(&t2,&bee1[i]);	// Table
			ozrotatepointx(&t2, rot2.x);
			ozrotatepointy(&t2, rot2.y);
			ozrotatepointz(&t2, rot2.z);
			t2.z += zf1; 			// Zoom factor
			ozplotpoint(&t2, &p2[i]);

			ozcopyvector(&t3,&bee2[i]);	// Table
			ozrotatepointx(&t3, rot3.x);
			ozrotatepointy(&t3, rot3.y);
			ozrotatepointz(&t3, rot3.z);
			t3.z += zf1; 			// Zoom factor
			ozplotpoint(&t3, &p3[i]);

			ozcopyvector(&t4,&bee3[i]);	// Table
			ozrotatepointx(&t4, rot4.x);
			ozrotatepointy(&t4, rot4.y);
			ozrotatepointz(&t4, rot4.z);
			t4.z += zf1; 			// Zoom factor
			ozplotpoint(&t4, &p4[i]);

			ozcopyvector(&t5,&bee4[i]);	// Table
			ozrotatepointx(&t5, rot5.x);
			ozrotatepointy(&t5, rot5.y);
			ozrotatepointz(&t5, rot5.z);
			t5.z += zf1; 			// Zoom factor
			ozplotpoint(&t5, &p5[i]);

			ozcopyvector(&t6,&bee5[i]);	// Table
			ozrotatepointx(&t6, rot6.x);
			ozrotatepointy(&t6, rot6.y);
			ozrotatepointz(&t6, rot6.z);
			t6.z += zf1; 			// Zoom factor
			ozplotpoint(&t6, &p6[i]);

		}


		rot.y = (rot.y+2)%360;			// add rotation
		rot.x = (rot.x+1)%360;
		rot.z = (rot.z+1)%360;

		rot2.y = (rot2.y+2)%360;			// add rotation
		rot2.x = (rot2.x+1)%360;
		rot2.z = (rot2.z+1)%360;
		rot3.y = (rot3.y+2)%360;			// add rotation
		rot3.x = (rot3.x+1)%360;
		rot3.z = (rot3.z+1)%360;
		rot4.y = (rot4.y+2)%360;			// add rotation
		rot4.x = (rot4.x+2)%360;
		rot4.z = (rot4.z+2)%360;
		
		rot5.y = (rot4.y+2)%360;			// add rotation
		rot5.x = (rot4.x+2)%360;
		rot5.z = (rot4.z+2)%360;
		rot6.y = (rot4.y+2)%360;			// add rotation
		rot6.x = (rot4.x+2)%360;
		rot6.z = (rot4.z+2)%360;
		#asm			

		ld	hl, $b000	// blit from buffer to screen.
		ld	de, $7000
		ld	bc, 2048
		ldir

//		ld	hl, $b000	// CLS buffer
//		ld	de, $b001
//		ld	(hl), 0
//		ld	bc, 2048
//		ldir



		ld	hl, $C001	// blit from background grafx at $C000 to buffer at $B000.
		ld	de, $b000
		ld	bc, 2048
		ldir

		ld	hl, $b000	// blit from background grafx at $C000 to buffer at $B000.
		ld	de, $c000
		ld	bc, 2048
		ldir

		ld	hl, $b000	// blit from background grafx at $C000 to buffer at $B000.
		ld	de, $c800-32
		ld	bc, 33
		ldir

		#endasm


// was ship, now butterfly.

		vz_line2(p[0].x + MX2, p[0].y + MY, p[1].x + MX2, p[1].y + MY,1);  //top
		vz_line2(p[0].x + MX2, p[0].y + MY, p[2].x + MX2, p[2].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[3].x + MX2, p[3].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[4].x + MX2, p[4].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[4].x + MX2, p[4].y + MY,1);  // legs
		vz_line2(p[1].x + MX2, p[1].y + MY, p[3].x + MX2, p[3].y + MY,1);
		vz_line2(p[2].x + MX2, p[2].y + MY, p[4].x + MX2, p[4].y + MY,1);

// bee
		vz_plot(p2[0].x + MX2, p2[0].y + MY,3);
		vz_plot(p2[1].x + MX2, p2[1].y + MY,3);
		vz_plot(p3[0].x + MX2, p3[0].y + MY,3);
		vz_plot(p3[1].x + MX2, p3[1].y + MY,3);
		vz_plot(p4[0].x + MX2, p4[0].y + MY,3);
		vz_plot(p4[1].x + MX2, p4[1].y + MY,3);
		vz_plot(MX2-p5[0].x , MY-p5[0].y ,1);
		vz_plot(MX2-p5[1].x , MY-p5[1].y ,1);
		vz_plot(MX2-p6[0].x , MY-p6[0].y ,1);
		vz_plot(MX2-p6[1].x , MY-p[1].y ,1);

//		vz_plot(p5[0].x + MX2, p6[1].y + MY,1);
	}
}



