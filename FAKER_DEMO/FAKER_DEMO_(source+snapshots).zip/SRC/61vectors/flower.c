/*
3d.c
Demo using standard Wizard 3d and 4d math functions
Copyright� 2002, Mark Hamilton
Flickering (non paged graphics) port to Z88DK by Stefano Bodrato - Oct 2003


- A silly demo thing whipper up by Dave.
- Using VZ_LINE2 ASM
- Uses background from Magnum Quest.
- Needs to run at Super Speed in VZEM for decent animation.


*/

// zcc +zx -vn showlib3d.c -o showlib3d -lndos -llib3d -create-app

//#include <oz.h>
#include <lib3d.h>
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <vz.h>

#define MX	60
#define MX2	60
#define MY	64/2 + 10



Vector_t ship[5]
=     { { -50 ,   -10,   -20  },
	{ -60 ,  -20,   -10  },
	{ -40 ,  -20,   -10  },
	{ -60 ,  0,   -10  },
	{ -40 ,  0,   -10 }};




int vz_line2(int x1, int y1, int x2, int y2, int c)
{
  #asm
	ld	hl, 2
	add	hl, sp
	ld	c, (hl)			// get C. C=colour
	inc	hl
	inc	hl
	ld	d, (hl)			// get Y2. d=Y2
	inc	hl
	inc	hl
	ld	e, (hl)			// get X2. e=X2
	inc	hl
	inc	hl
	ld	a, (hl)			// get Y1. temp make A=Y1
	inc	hl
	inc	hl
	ld	l, (hl)			// get X1. L=x1
	ld	h, a			// set h=Y1 from temp A.

   
   ; c = colour
   ; l = x1
   ; h = y1
   ; e = x2
   ; d = y2
   
asmentry:

   ld a,e
   cp l
   jr nc, line1
   ex de,hl                  ; swap so that x1 < x2

line1:

   ld a,e
   sub l                     ; dx
   ld e,a                    ; save dx

   ld a,d
   sub h
   jp c, lup                 ; negative (up)

ldn:

   ld d,a                    ; save dy
   cp e                      ; dy < dx ?
   jr c, ldnx

ldny:

   ld b,a                    ; count = dy
   srl a                     ; /2 -> overflow

ldny1:

   push af		; push return
   push bc		; push colour
;   push de		; push Y2/X2
   push hl		; push Y1/X1
;=============================

;; ----- void __CALLEE__ vz_plot_callee(int x, int y, int c)
;;   pop af  	return add
;;   pop bc	colour
;;   pop de	Y
;;   pop hl	X
;;   push af	push return add
;;   ld h,e
;;
;;   ----  h=y1 / l=x1
;;         d=y2 / e=x2


   ; l = x
   ; h = y
   ; c = colour



;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
      ld a,$fc
pset1:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset1
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   
   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m

   inc h                     ; y++
   sub e                     ; overflow -= dx
   jr nc, ldny1
 
   inc l                     ; x++
   add a,d                   ; overflow += dy
   jp ldny1

ldnx:

   ld a,e                    ; get dx
   ld b,a                    ; count = dx
   srl a                     ; /2 -> overflow
   
ldnx1:

   push af
   push bc
;   push de
   push hl
;=============================
;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;  and 3
;  ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
      ld a,$fc
pset2:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset2
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   
   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m
   
   inc l                     ; x++
   sub d                     ; overflow -= dy
   jr nc, ldnx1

   inc h                     ; y++
   add a,e                   ; overflow += dx
   jp ldnx1

lup:

   neg                       ; make dy positive
   ld d,a                    ; save dy
   cp e                      ; dy < dx ?
   jr c, lupx

lupy:

   ld b,a                    ; count = dy
   srl a                     ; /2 -> overflow

lupy1:

   push af
   push bc
;   push de
   push hl

;=============================
;   ld h,e

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l

   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
   ld a,$fc
pset3:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset3
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   


   pop hl
;   pop de
   pop bc
   pop af

   dec b                     ; done?
   ret m

   dec h                     ; y--
   sub e                     ; overflow -= dx
   jr nc, lupy1

   inc l                     ; x++
   add a,d                   ; overflow += dy
   jp lupy1

lupx:

   ld a,e                    ; get dx
   ld b,a                    ; count = dx
   srl a                     ; /2 -> overflow

lupx1:

   push af
   push bc
;   push de
   push hl



;=============================

   ; l = x
   ; h = y
   ; c = colour

;   ld	a,c
;   and 3
;   ld	c,a
;   ld a,h
   ld a,l
   sla l                     ; calculate screen offset
   srl h
   rr l
   srl h
   rr l
   srl h
   rr l
   and $03                   ; pixel offset   
   inc a
   ld b,a
   ld a,$fc
pset4:
   rrca
   rrca
   rrc c
   rrc c
   djnz pset4
;   ld de,(base_graphics)
;   add hl,de
	add hl, $B000
   and (hl)
   or c
   ld (hl),a
;==================================   




   pop hl
;   pop de
   pop bc
   pop af
   
   dec b                     ; done?
   ret m

   inc l                     ; x++
   sub d                     ; overflow -= dy
   jr nc, lupx1

   dec h                     ; y--
   add a,e                   ; overflow += dx
   jp lupx1

   #endasm
}




// =======================
// Data of a sunny flower.
// =======================
void background (void){		
 	#asm

	ld	hl, backg	//Loads background to $C000.
	ld	de, $c000
	ld	bc, 2048
	ldir
	ret

backg:
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0BF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FE,$0AA,$0AF,$0FE,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0AA,$0BF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0AA,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0EB,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0EB,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0FF,$0FF,$0EF,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF
 defb $0FA,$0FF,$0FF,$0FF,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0AA,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0FF,$0D5,$055,$07F,$0FE,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0FD,$055,$055,$057,$0FB,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FF,$0F5,$055,$055,$055,$07F,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF
 defb $0FF,$0D5,$059,$055,$055,$05F,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF
 defb $0FF,$055,$066,$055,$055,$057,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BF
 defb $0FF,$055,$059,$055,$059,$055,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FD,$055,$055,$055,$066,$055,$0FF,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0FD,$055,$055,$055,$059,$055,$07F,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FD,$055,$055,$055,$055,$055,$07F,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF,$0FF
 defb $0FD,$055,$055,$055,$055,$055,$07F,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BF,$0FF
 defb $0FD,$055,$065,$055,$055,$055,$07F,$0FF,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF,$0FF
 defb $0FD,$055,$059,$055,$065,$055,$07F,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF,$0FF
 defb $0FD,$055,$056,$055,$095,$055,$07F,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0FF,$0FF
 defb $0FD,$055,$055,$0AA,$055,$055,$07F,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0BF,$0FF
 defb $0FF,$055,$055,$055,$055,$055,$07F,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF,$0FF
 defb $0FF,$055,$055,$055,$055,$055,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB,$0FF
 defb $0FB,$0D5,$055,$055,$055,$055,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AF,$0F5,$055,$055,$055,$056,$0FF,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0BF,$0FD,$055,$055,$055,$05F,$0AA,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0FF,$0FF,$0D5,$055,$055,$07F,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AB
 defb $0FF,$0FF,$0FD,$055,$057,$0FF,$0EA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FF,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FE,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FE,$0FF,$0FF,$0FF,$0FF,$0FA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AF
 defb $0FF,$0FA,$0FF,$0FF,$0EF,$0FF,$0F2,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0FF,$0AA,$0FF,$0FF,$0AB,$0FF,$0C2,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0FF,$0FF,$0AA,$0A0,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0FF,$0FF,$0AA,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0BF,$0FE,$0A8,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AF,$0FA,$0A0,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0A8
 defb $00A,$0AA,$0AA,$08A,$080,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $000,$02A,$0AA,$08A,$080,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $000,$002,$0AA,$08A,$000,$000,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $080,$000,$0AA,$08A,$000,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0A0,$000,$00A,$088,$000,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0A0,$000,$002,$088,$000,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0A8,$000,$002,$088,$000,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$000,$000,$080,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$080,$000,$082,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0A0,$000,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0A8,$000,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$080,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$082,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A0,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A0,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A0,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A8,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0A8,$02A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$00A,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$002,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$082,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA
 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA

 defb $0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA,$0AA


	#endasm
}



void main(void)
{
	static Vector_t rot;
	static Vector_t t;
	static Point_t  p[5];

	static int i;
	static int zf = 50;
	static int zf1 = 0;
	static int zf2 = 150;

	vz_mode(1);

	background();

	#asm
		di
	#endasm

	while(1){


		for(i=0;i<5;i++) {
			ozcopyvector(&t,&ship[i]);	// Table
			ozrotatepointx(&t, rot.x);
			ozrotatepointy(&t, rot.y);
			ozrotatepointz(&t, rot.z);
			t.z += zf; 			// Zoom factor
			ozplotpoint(&t, &p[i]);
		}


		rot.y = (rot.y+2)%360;			// add rotation
		rot.x = (rot.x+1)%360;
		rot.z = (rot.z+1)%360;

		
		#asm			

		ld	hl, $b000	// blit from buffer to screen.
		ld	de, $7000
		ld	bc, 2048
		ldir

//		ld	hl, $b000	// CLS buffer
//		ld	de, $b001
//		ld	(hl), 0
//		ld	bc, 2048
//		ldir



		ld	hl, $C000	// blit from background grafx at $C000 to buffer at $B000.
		ld	de, $b000
		ld	bc, 2048
		ldir

		#endasm


// was ship, now butterfly.

		vz_line2(p[0].x + MX2, p[0].y + MY, p[1].x + MX2, p[1].y + MY,1);  //top
		vz_line2(p[0].x + MX2, p[0].y + MY, p[2].x + MX2, p[2].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[3].x + MX2, p[3].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[4].x + MX2, p[4].y + MY,1);
		vz_line2(p[0].x + MX2, p[0].y + MY, p[4].x + MX2, p[4].y + MY,1);  // legs
		vz_line2(p[1].x + MX2, p[1].y + MY, p[3].x + MX2, p[3].y + MY,1);
		vz_line2(p[2].x + MX2, p[2].y + MY, p[4].x + MX2, p[4].y + MY,1);

	}
}



